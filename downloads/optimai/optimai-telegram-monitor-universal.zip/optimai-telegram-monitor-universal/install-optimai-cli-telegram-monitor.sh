#!/usr/bin/env bash
# OptimAI CLI Node Telegram Monitor installer (Ubuntu + systemd)
# Run from the extracted release folder: sudo ./install-optimai-cli-telegram-monitor.sh

set -euo pipefail

SERVICE_NAME="${OPTIMAI_SERVICE_NAME:-optimai.service}"
INSTALL_DIR="/usr/local/lib/optimai-telegram-monitor"
MONITOR_NAME="optimai-telegram-monitor.sh"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SOURCE_MONITOR="$SCRIPT_DIR/$MONITOR_NAME"
NODE_USER="${SUDO_USER:-root}"
NODE_HOME="$(getent passwd "$NODE_USER" | cut -d: -f6)"

fail() { echo "HATA: $*" >&2; exit 1; }
info() { echo "==> $*"; }
run_as_node_user() {
  if [[ "$NODE_USER" == "root" ]]; then "$@"; else sudo -H -u "$NODE_USER" "$@"; fi
}

[[ "${EUID}" -eq 0 ]] || fail "Bu script root olarak çalıştırılmalı: sudo ./$0"
if [[ "${1:-}" == "--uninstall" ]]; then
  [[ -x "$INSTALL_DIR/$MONITOR_NAME" ]] || fail "Kurulu monitor bulunamadı."
  [[ -f "$INSTALL_DIR/install-owner" ]] && NODE_USER="$(<"$INSTALL_DIR/install-owner")"
  run_as_node_user "$INSTALL_DIR/$MONITOR_NAME" --uninstall
  rm -rf "$INSTALL_DIR"
  info "OptimAI Telegram Monitor kaldırıldı. Telegram bot hesabınız BotFather'da kalır."
  exit 0
fi
[[ -f "$SOURCE_MONITOR" ]] || fail "$MONITOR_NAME aynı klasörde bulunamadı. Release paketini eksiksiz çıkarın."
command -v docker >/dev/null 2>&1 || fail "Docker bulunamadı."
command -v curl >/dev/null 2>&1 || fail "curl bulunamadı."

info "OptimAI node servisi doğrulanıyor (kullanıcı: $NODE_USER)"
CLI_STATUS="$(run_as_node_user optimai-cli node status 2>/dev/null || true)"
if systemctl is-active --quiet "$SERVICE_NAME"; then
  docker info >/dev/null 2>&1 || fail "Docker erişilebilir değil."
elif ! grep -q '^Node running' <<< "$CLI_STATUS"; then
  fail "Node çalışmıyor. Önce OptimAI node'u başlatın."
fi

DEVICE_OUTPUT="$(run_as_node_user optimai-cli node device 2>/dev/null)" || fail "optimai-cli node device çalışmadı."
NODE_NAME="$(awk -F': ' '/^Device:/ {print $2; exit}' <<< "$DEVICE_OUTPUT")"
NODE_ID="$(awk -F': ' '/^ID:/ {print $2; exit}' <<< "$DEVICE_OUTPUT")"
[[ -n "$NODE_NAME" && -n "$NODE_ID" ]] || fail "Node adı veya ID okunamadı."

STARTED_AT="$(systemctl show "$SERVICE_NAME" -p ActiveEnterTimestamp --value 2>/dev/null || true)"
[[ -n "$STARTED_AT" && "$STARTED_AT" != "n/a" ]] || STARTED_AT="CLI process start time will be used"

info "Node bulundu: $NODE_NAME"
info "Node ID: $NODE_ID"
info "İmza sayacı başlangıcı: $STARTED_AT"

install -d -m 755 "$INSTALL_DIR"
install -m 755 "$SOURCE_MONITOR" "$INSTALL_DIR/$MONITOR_NAME"
install -m 755 "$0" "$INSTALL_DIR/install-optimai-cli-telegram-monitor.sh"
install -m 644 "$SCRIPT_DIR/README_TR.md" "$INSTALL_DIR/README_TR.md"
printf '%s\n' "$NODE_USER" > "$INSTALL_DIR/install-owner"

info "Telegram bilgilerini girin. Bot token ekran üzerinde gösterilmez."
run_as_node_user "$INSTALL_DIR/$MONITOR_NAME" --install

info "Kurulum tamamlandı. Doğrulama için: $INSTALL_DIR/$MONITOR_NAME --status"
