# OptimAI Telegram Monitor — Windows PowerShell 5.1+
# It only sends health/reminder notifications; it never handles wallet signatures.
param([ValidateSet('Install','Check','Status','MarkSigned','Uninstall','Help')][string]$Action = 'Help')

$AppHome = if ($env:OPTIMAI_MONITOR_HOME) { $env:OPTIMAI_MONITOR_HOME } else { Join-Path $env:LOCALAPPDATA 'OptimAI-Telegram-Monitor' }
$ConfigFile = Join-Path $AppHome 'config.json'
$StateFile = Join-Path $AppHome 'state.json'
$TaskName = 'OptimAI Telegram Monitor'
$SignatureLifetime = [TimeSpan]::FromDays(14)

function Load-MonitorData {
  if (!(Test-Path $ConfigFile)) { throw 'Kurulum bulunamadı. Önce: .\OptimAI-Telegram-Monitor.ps1 -Action Install' }
  $script:Config = Get-Content $ConfigFile -Raw | ConvertFrom-Json
  $script:State = if (Test-Path $StateFile) { Get-Content $StateFile -Raw | ConvertFrom-Json } else { [pscustomobject]@{ SignedAtUtc = (Get-Date).ToUniversalTime().ToString('o'); LastNodeState = 'unknown'; LastSignatureNotice = ''; LastDailyReport = '' } }
}
function Save-State { $State | ConvertTo-Json | Set-Content $StateFile -Encoding UTF8 }
function ConvertFrom-SecureStringPlaintext([System.Security.SecureString]$SecureValue) {
  $ptr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($SecureValue)
  try { return [Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr) }
  finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr) }
}
function Send-Telegram([string]$Text) {
  $uri = "https://api.telegram.org/bot$($Config.BotToken)/sendMessage"
  Invoke-RestMethod -Method Post -Uri $uri -Body @{ chat_id = $Config.ChatId; text = $Text; disable_web_page_preview = 'true' } | Out-Null
}
function Get-NodeIdentity {
  $output = & optimai-cli node device 2>$null
  if ($LASTEXITCODE -ne 0) { throw 'OptimAI CLI node device komutu çalışmadı.' }
  $nameLine = $output | Where-Object { $_ -match '^Device:\s*(.+)$' } | Select-Object -First 1
  $idLine = $output | Where-Object { $_ -match '^ID:\s*(.+)$' } | Select-Object -First 1
  if (!$nameLine -or !$idLine) { throw 'Node adı veya ID otomatik okunamadı.' }
  return @{ Name=([regex]::Match($nameLine, '^Device:\s*(.+)$').Groups[1].Value.Trim()); Id=([regex]::Match($idLine, '^ID:\s*(.+)$').Groups[1].Value.Trim()) }
}
function Get-NodeStartedAt {
  $status = & optimai-cli node status 2>$null
  $match = [regex]::Match(($status -join "`n"), 'Node running \(pid (\d+)\)')
  if (!$match.Success) { throw 'OptimAI node başlangıç PID bilgisi okunamadı.' }
  return (Get-Process -Id ([int]$match.Groups[1].Value) -ErrorAction Stop).StartTime.ToUniversalTime()
}
function Get-NodeState {
  $cli = Get-Process -Name 'optimai-cli' -ErrorAction SilentlyContinue
  $docker = Get-Command docker -ErrorAction SilentlyContinue
  $dockerOk = $false
  if ($docker) { & docker info *> $null; $dockerOk = ($LASTEXITCODE -eq 0) }
  if ($cli -and $dockerOk) { return @{ State='healthy'; Detail='process=running, docker=ok' } }
  if (!$cli) { return @{ State='down'; Detail='optimai-cli process not found' } }
  return @{ State='unknown'; Detail='docker unavailable' }
}
function Get-DurationText([TimeSpan]$Span) {
  $sign = if ($Span.TotalSeconds -lt 0) { '-' } else { '' }; $s = [Math]::Abs($Span.TotalSeconds)
  return '{0}{1}d {2:00}h {3:00}m' -f $sign, [Math]::Floor($s / 86400), [Math]::Floor(($s % 86400) / 3600), [Math]::Floor(($s % 3600) / 60)
}
function Get-Notice([TimeSpan]$Remaining) {
  if ($Remaining.TotalSeconds -le 0) { 'expired' }
  elseif ($Remaining.TotalHours -le 6) { '6h' }
  elseif ($Remaining.TotalDays -le 1) { '24h' }
  elseif ($Remaining.TotalDays -le 3) { '3d' }
  elseif ($Remaining.TotalDays -le 7) { '7d' }
  else { '' }
}
function Get-SystemSummary {
  $disk = Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='C:'"; $os = Get-CimInstance Win32_OperatingSystem
  "Disk: {0:N0}% used`nRAM: {1:N0}/{2:N0} MiB`nHost: {3}" -f ((($disk.Size - $disk.FreeSpace) / $disk.Size) * 100), (($os.TotalVisibleMemorySize - $os.FreePhysicalMemory) / 1024), ($os.TotalVisibleMemorySize / 1024), $env:COMPUTERNAME
}
function Invoke-Check {
  Load-MonitorData; $node = Get-NodeState; $remaining = ([datetime]::UtcNow - ([datetime]$State.SignedAtUtc + $SignatureLifetime)).Negate(); $notice = Get-Notice $remaining
  if ($node.State -ne $State.LastNodeState) {
    $emoji = if ($node.State -eq 'healthy') { '✅' } elseif ($node.State -eq 'down') { '🚨' } else { '⚠️' }
    Send-Telegram "$emoji $($Config.NodeName): node durumu $($node.State).`n$($node.Detail)"; $State.LastNodeState = $node.State
  }
  if ($notice -and $notice -ne $State.LastSignatureNotice) {
    if ($notice -eq 'expired') { Send-Telegram "🚨 $($Config.NodeName): 14 günlük imza süresi dolmuş olabilir. Manuel yenilemeden sonra MarkSigned çalıştırın." }
    else { Send-Telegram "⚠️ $($Config.NodeName): imza yenilemeye $(Get-DurationText $remaining) kaldı." }
    $State.LastSignatureNotice = $notice
  }
  $today = (Get-Date).ToUniversalTime().ToString('yyyy-MM-dd')
  if ($State.LastDailyReport -ne $today) { Send-Telegram "ℹ️ $($Config.NodeName) günlük durum`nNode ID: $($Config.NodeId)`nNode: $($node.State) ($($node.Detail))`nİmza geri sayımı: $(Get-DurationText $remaining)`n$(Get-SystemSummary)"; $State.LastDailyReport = $today }
  Save-State
}
function Install-Monitor {
  New-Item -ItemType Directory -Path $AppHome -Force | Out-Null
  $secureToken = Read-Host 'Telegram bot token' -AsSecureString; $token = ConvertFrom-SecureStringPlaintext $secureToken
  if (!$token) { throw 'Telegram bot token zorunlu.' }
  Write-Host 'Telegram’da botunuzu açın, /start gönderin ve burada Enter’a basın.'; Read-Host 'Hazır olduğunuzda Enter' | Out-Null
  $updates = Invoke-RestMethod -Uri "https://api.telegram.org/bot$token/getUpdates"
  $chat = ($updates.result | ForEach-Object { $_.message.chat.id } | Where-Object { $_ } | Select-Object -Last 1)
  if (!$chat) { throw 'Chat ID otomatik alınamadı. Botunuza /start gönderip tekrar deneyin.' }
  $identity = Get-NodeIdentity; Write-Host "Bulunan node: $($identity.Name) ($($identity.Id))"
  $signedAt = Get-NodeStartedAt; Write-Host "İmza sayacı node başlangıcından alındı: $($signedAt.ToString('u'))"
  # Limit the locally stored bot token to the current Windows account.
  $windowsIdentity = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
  & icacls $AppHome /inheritance:r /grant:r "$windowsIdentity:(OI)(CI)F" | Out-Null
  @{ BotToken=$token; ChatId=$chat; NodeName=$identity.Name; NodeId=$identity.Id } | ConvertTo-Json | Set-Content $ConfigFile -Encoding UTF8
  @{ SignedAtUtc=$signedAt.ToString('o'); LastNodeState='unknown'; LastSignatureNotice=''; LastDailyReport='' } | ConvertTo-Json | Set-Content $StateFile -Encoding UTF8
  $scriptPath = $PSCommandPath; $command = "powershell.exe -NoProfile -ExecutionPolicy Bypass -File `"$scriptPath`" -Action Check"
  schtasks /Create /TN $TaskName /TR $command /SC MINUTE /MO 15 /F | Out-Null
  Invoke-Check; Write-Host 'Kurulum tamamlandı. İmzayı yenilediğinizde MarkSigned çalıştırın.'
}
function Mark-Signed { Load-MonitorData; $State.SignedAtUtc = (Get-Date).ToUniversalTime().ToString('o'); $State.LastSignatureNotice=''; Save-State; Send-Telegram "✅ $($Config.NodeName): imza yenilemesi kaydedildi. Yeni 14 günlük sayaç başladı." }
switch ($Action) {
  'Install' { Install-Monitor }; 'Check' { Invoke-Check }; 'Status' { Load-MonitorData; $r = ([datetime]$State.SignedAtUtc + $SignatureLifetime) - [datetime]::UtcNow; "$($Config.NodeName): imza geri sayımı $(Get-DurationText $r)" }; 'MarkSigned' { Mark-Signed }; 'Uninstall' { schtasks /Delete /TN $TaskName /F }; default { Write-Host 'Kullanım: -Action Install | Check | Status | MarkSigned | Uninstall' }
}
