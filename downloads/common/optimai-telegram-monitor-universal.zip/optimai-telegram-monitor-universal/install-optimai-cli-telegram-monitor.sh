#!/usr/bin/env bash
# OptimAI CLI Node Telegram Monitor installer (Ubuntu + systemd)
# Run from the extracted release folder: sudo ./install-optimai-cli-telegram-monitor.sh

set -euo pipefail

SERVICE_NAME="${OPTIMAI_SERVICE_NAME:-optimai.service}"
INSTALL_DIR="/usr/local/lib/optimai-telegram-monitor"
MONITOR_NAME="optimai-telegram-monitor.sh"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SOURCE_MONITOR="$SCRIPT_DIR/$MONITOR_NAME"

fail() { echo "HATA: $*" >&2; exit 1; }
info() { echo "==> $*"; }

[[ "${EUID}" -eq 0 ]] || fail "Bu script root olarak çalıştırılmalı: sudo ./$0"
if [[ "${1:-}" == "--uninstall" ]]; then
  [[ -x "$INSTALL_DIR/$MONITOR_NAME" ]] || fail "Kurulu monitor bulunamadı."
  "$INSTALL_DIR/$MONITOR_NAME" --uninstall
  rm -rf "$INSTALL_DIR"
  info "OptimAI Telegram Monitor kaldırıldı. Telegram bot hesabınız BotFather'da kalır."
  exit 0
fi
[[ -f "$SOURCE_MONITOR" ]] || fail "$MONITOR_NAME aynı klasörde bulunamadı. Release paketini eksiksiz çıkarın."
command -v systemctl >/dev/null 2>&1 || fail "systemd bulunamadı; bu Ubuntu Clean Node kurulum betiğidir."
command -v optimai-cli >/dev/null 2>&1 || fail "optimai-cli bulunamadı. Önce OptimAI CLI node kurulumunu tamamlayın."
command -v docker >/dev/null 2>&1 || fail "Docker bulunamadı."
command -v curl >/dev/null 2>&1 || fail "curl bulunamadı."

info "OptimAI node servisi doğrulanıyor"
systemctl is-active --quiet "$SERVICE_NAME" || fail "$SERVICE_NAME aktif değil. Önce node'u başlatın."
docker info >/dev/null 2>&1 || fail "Docker erişilebilir değil."

DEVICE_OUTPUT="$(optimai-cli node device 2>/dev/null)" || fail "optimai-cli node device çalışmadı."
NODE_NAME="$(awk -F': ' '/^Device:/ {print $2; exit}' <<< "$DEVICE_OUTPUT")"
NODE_ID="$(awk -F': ' '/^ID:/ {print $2; exit}' <<< "$DEVICE_OUTPUT")"
[[ -n "$NODE_NAME" && -n "$NODE_ID" ]] || fail "Node adı veya ID okunamadı."

STARTED_AT="$(systemctl show "$SERVICE_NAME" -p ActiveEnterTimestamp --value)"
[[ -n "$STARTED_AT" && "$STARTED_AT" != "n/a" ]] || fail "Node servis başlangıç zamanı okunamadı."

info "Node bulundu: $NODE_NAME"
info "Node ID: $NODE_ID"
info "İmza sayacı başlangıcı: $STARTED_AT"

install -d -m 755 "$INSTALL_DIR"
install -m 755 "$SOURCE_MONITOR" "$INSTALL_DIR/$MONITOR_NAME"
install -m 755 "$0" "$INSTALL_DIR/install-optimai-cli-telegram-monitor.sh"
install -m 644 "$SCRIPT_DIR/README_TR.md" "$INSTALL_DIR/README_TR.md"

info "Telegram bilgilerini girin. Bot token ekran üzerinde gösterilmez."
"$INSTALL_DIR/$MONITOR_NAME" --install

info "Kurulum tamamlandı. Doğrulama için: $INSTALL_DIR/$MONITOR_NAME --status"
