#!/usr/bin/env bash
# OptimAI Telegram Monitor — Linux and macOS
# This script never signs in to OptimAI or controls a wallet. It only monitors
# the local node and reminds the operator to renew their signature manually.

set -euo pipefail

APP_HOME="${OPTIMAI_MONITOR_HOME:-$HOME/.config/optimai-telegram-monitor}"
CONFIG_FILE="$APP_HOME/config"
STATE_FILE="$APP_HOME/state"
SERVICE_NAME="${OPTIMAI_SERVICE_NAME:-optimai.service}"
SIGNATURE_LIFETIME_SECONDS=$((14 * 24 * 60 * 60))

now_epoch() { date +%s; }
iso_now() { date -u '+%Y-%m-%dT%H:%M:%SZ'; }
format_epoch() {
  if [[ "$(uname)" == "Darwin" ]]; then date -r "$1" '+%Y-%m-%d %H:%M %Z'; else date -d "@$1" '+%Y-%m-%d %H:%M %Z'; fi
}

ensure_home() { mkdir -p "$APP_HOME"; chmod 700 "$APP_HOME"; }

load_config() {
  if [[ ! -f "$CONFIG_FILE" ]]; then
    echo "Kurulum bulunamadı. Önce: $0 --install" >&2
    exit 1
  fi
  # shellcheck disable=SC1090
  source "$CONFIG_FILE"
  # shellcheck disable=SC1090
  [[ -f "$STATE_FILE" ]] && source "$STATE_FILE"
  : "${BOT_TOKEN:?BOT_TOKEN eksik}" "${CHAT_ID:?CHAT_ID eksik}" "${NODE_NAME:?NODE_NAME eksik}"
  NODE_ID="${NODE_ID:-bilinmiyor}"
  SIGNED_AT_EPOCH="${SIGNED_AT_EPOCH:-$(now_epoch)}"
  LAST_NODE_STATE="${LAST_NODE_STATE:-unknown}"
  LAST_SIGNATURE_NOTICE="${LAST_SIGNATURE_NOTICE:-}"
  LAST_DAILY_REPORT="${LAST_DAILY_REPORT:-}"
}

save_state() {
  umask 077
  cat > "$STATE_FILE" <<EOF
SIGNED_AT_EPOCH=$SIGNED_AT_EPOCH
LAST_NODE_STATE=$LAST_NODE_STATE
LAST_SIGNATURE_NOTICE=$LAST_SIGNATURE_NOTICE
LAST_DAILY_REPORT=$LAST_DAILY_REPORT
EOF
}

telegram() {
  local text="$1"
  text="${text//\\n/$'\n'}"
  curl --fail --silent --show-error --max-time 20 \
    --data-urlencode "chat_id=$CHAT_ID" \
    --data-urlencode "text=$text" \
    --data-urlencode "disable_web_page_preview=true" \
    "https://api.telegram.org/bot${BOT_TOKEN}/sendMessage" >/dev/null
}

detect_chat_id() {
  local updates
  echo "Telegram'da botunuzu açın, /start gönderin; ardından burada Enter'a basın." >&2
  read -r -p 'Hazır olduğunuzda Enter: ' _
  updates="$(curl --fail --silent --show-error --max-time 20 "https://api.telegram.org/bot${BOT_TOKEN}/getUpdates")" || return 1
  if command_exists python3; then
    CHAT_ID="$(python3 -c 'import json,sys; u=json.load(sys.stdin).get("result",[]); print(next((x.get("message",{}).get("chat",{}).get("id") for x in reversed(u) if x.get("message",{}).get("chat",{}).get("id") is not None), ""))' <<< "$updates")"
  else
    CHAT_ID="$(sed -nE 's/.*"chat"[[:space:]]*:[[:space:]]*\{[[:space:]]*"id"[[:space:]]*:[[:space:]]*(-?[0-9]+).*/\1/p' <<< "$updates" | tail -n 1)"
  fi
  [[ "$CHAT_ID" =~ ^-?[0-9]+$ ]]
}

verify_bot_token() {
  curl --fail --silent --show-error --max-time 20 "https://api.telegram.org/bot${BOT_TOKEN}/getMe" >/dev/null
}

command_exists() { command -v "$1" >/dev/null 2>&1; }

detect_node_identity() {
  command_exists optimai-cli || return 1
  local output
  output="$(optimai-cli node device 2>/dev/null)" || return 1
  DETECTED_NODE_NAME="$(awk -F': ' '/^Device:/ {print $2; exit}' <<< "$output")"
  DETECTED_NODE_ID="$(awk -F': ' '/^ID:/ {print $2; exit}' <<< "$output")"
  [[ -n "$DETECTED_NODE_NAME" && -n "$DETECTED_NODE_ID" ]]
}

node_state() {
  local systemd_state="" docker_state="" cli_status=""

  if command_exists systemctl && systemctl cat "$SERVICE_NAME" >/dev/null 2>&1; then
    systemd_state="$(systemctl is-active "$SERVICE_NAME" 2>/dev/null || true)"
  fi
  if command_exists docker; then
    docker info >/dev/null 2>&1 && docker_state="ok" || docker_state="unavailable"
  else
    docker_state="missing"
  fi
  if command_exists optimai-cli; then
    cli_status="$(optimai-cli node status 2>/dev/null || true)"
  fi

  if grep -q '^Node running' <<< "$cli_status" && grep -q '^Docker: available' <<< "$cli_status"; then
    echo "healthy|cli=node running, docker=available"
  elif [[ "$systemd_state" == "active" && "$docker_state" == "ok" ]]; then
    echo "healthy|systemd=active, docker=ok"
  elif [[ -n "$systemd_state" && "$systemd_state" != "active" ]]; then
    echo "down|systemd=${systemd_state:-unknown}, docker=${docker_state:-unknown}"
  elif pgrep -f '[o]ptimai-cli.*node start' >/dev/null 2>&1 && [[ "$docker_state" == "ok" ]]; then
    echo "healthy|process=running, docker=ok"
  else
    echo "unknown|systemd=${systemd_state:-not-found}, docker=${docker_state:-unknown}"
  fi
}

system_summary() {
  local disk memory uptime
  disk="$(df -P "$HOME" | awk 'NR==2 {print $5 " used"}')"
  if command_exists free; then
    memory="$(free -m | awk '/Mem:/ {printf "%s/%s MiB", $3, $2}')"
  elif command_exists vm_stat; then
    memory="macOS memory check"
  else
    memory="unknown"
  fi
  uptime="$(uptime | sed 's/.*up /up /' | cut -d, -f1)"
  printf '💾 Disk: %s\n🧠 RAM: %s\n⏱ Sunucu: %s' "$disk" "$memory" "$uptime"
}

short_node_id() {
  if (( ${#NODE_ID} > 16 )); then printf '%s…%s' "${NODE_ID:0:8}" "${NODE_ID: -4}"; else printf '%s' "$NODE_ID"; fi
}

signature_notice_level() {
  local remaining="$1"
  if (( remaining <= 0 )); then echo "expired"
  elif (( remaining <= 6 * 3600 )); then echo "6h"
  elif (( remaining <= 24 * 3600 )); then echo "24h"
  elif (( remaining <= 3 * 86400 )); then echo "3d"
  elif (( remaining <= 7 * 86400 )); then echo "7d"
  else echo ""; fi
}

human_duration() {
  local seconds="$1" sign=""
  if (( seconds < 0 )); then sign="-"; seconds=$((-seconds)); fi
  printf '%s%dd %02dh %02dm' "$sign" "$((seconds / 86400))" "$(((seconds % 86400) / 3600))" "$(((seconds % 3600) / 60))"
}

service_started_epoch() {
  local started parsed status pid process_started
  if command_exists systemctl; then
    started="$(systemctl show "$SERVICE_NAME" -p ActiveEnterTimestamp --value 2>/dev/null || true)"
    if [[ -n "$started" && "$started" != "n/a" ]]; then
      parsed="$(date -d "$started" '+%s' 2>/dev/null || true)"
      [[ "$parsed" =~ ^[0-9]+$ ]] && { printf '%s\n' "$parsed"; return; }
    fi
  fi
  command_exists optimai-cli || return 1
  status="$(optimai-cli node status 2>/dev/null || true)"
  pid="$(sed -nE 's/^Node running \(pid ([0-9]+)\).*/\1/p' <<< "$status" | head -n 1)"
  [[ "$pid" =~ ^[0-9]+$ ]] || return 1
  process_started="$(ps -p "$pid" -o lstart= 2>/dev/null | xargs)"
  [[ -n "$process_started" ]] || return 1
  if [[ "$(uname)" == "Darwin" ]]; then
    parsed="$(date -j -f '%a %b %e %T %Y' "$process_started" '+%s' 2>/dev/null || true)"
  else
    parsed="$(date -d "$process_started" '+%s' 2>/dev/null || true)"
  fi
  [[ "$parsed" =~ ^[0-9]+$ ]] || return 1
  printf '%s\n' "$parsed"
}

initial_signature_time() {
  local service_started
  service_started="$(service_started_epoch || true)"
  if [[ -n "$service_started" ]]; then
    echo "İmza sayacı node başlangıcından alındı: $(date -d "@$service_started" '+%Y-%m-%d %H:%M %Z')" >&2
    printf '%s\n' "$service_started"
    return
  fi
  echo "Node başlangıç zamanı okunamadı. İmza sayacı otomatik kurulamadı." >&2
  exit 1
}

check() {
  load_config
  local result status detail current remaining level today observed_started node_started node_uptime
  observed_started="$(service_started_epoch || true)"
  if [[ "$observed_started" =~ ^[0-9]+$ && "$observed_started" -gt "$SIGNED_AT_EPOCH" ]]; then
    SIGNED_AT_EPOCH="$observed_started"
    LAST_SIGNATURE_NOTICE=""
    telegram "🔄 $NODE_NAME: node başlangıç zamanı değişti. 14 günlük imza sayacı otomatik olarak yeniden eşitlendi ($(date -d "@$SIGNED_AT_EPOCH" '+%Y-%m-%d %H:%M %Z'))."
  fi
  result="$(node_state)"; status="${result%%|*}"; detail="${result#*|}"
  current="$(now_epoch)"; remaining=$((SIGNED_AT_EPOCH + SIGNATURE_LIFETIME_SECONDS - current))
  node_started="${observed_started:-$SIGNED_AT_EPOCH}"
  node_uptime=$((current - node_started))
  level="$(signature_notice_level "$remaining")"

  if [[ "$status" != "$LAST_NODE_STATE" ]]; then
    if [[ "$status" == "healthy" ]]; then
      telegram "🟢 OPTIMAI CLI NODE\n\n🏷 Node: $NODE_NAME\n✅ Durum: Çevrimiçi\n🔧 $detail"
    elif [[ "$status" == "down" ]]; then
      telegram "🚨 OPTIMAI NODE UYARISI\n\n🏷 Node: $NODE_NAME\n❌ Durum: Çalışmıyor\n🔧 $detail\n\n🛠 Kontrol: systemctl status $SERVICE_NAME --no-pager"
    else
      telegram "⚠️ OPTIMAI NODE KONTROLÜ\n\n🏷 Node: $NODE_NAME\n❓ Durum: Doğrulanamadı\n🔧 $detail"
    fi
    LAST_NODE_STATE="$status"
  fi

  if [[ -n "$level" && "$level" != "$LAST_SIGNATURE_NOTICE" ]]; then
    if [[ "$level" == "expired" ]]; then
      telegram "🚨 İMZA SÜRESİ DOLDU\n\n🏷 Node: $NODE_NAME\n🔐 Süre: ${human_duration "$((-remaining))"} geçti\n\n👉 OptimAI giriş/imza yenilemesini tamamlayın ve node'u yeniden başlatın. Sayaç yeni servis başlangıcına otomatik eşitlenir."
    else
      telegram "🔐 İMZA HATIRLATMASI\n\n🏷 Node: $NODE_NAME\n⏳ Kalan süre: $(human_duration "$remaining")\n\n👉 İmza yenilemesi manuel yapılmalıdır."
    fi
    LAST_SIGNATURE_NOTICE="$level"
  fi

  today="$(date -u +%F)"
  if [[ "$today" != "$LAST_DAILY_REPORT" ]]; then
    telegram "📊 OPTIMAI CLI NODE\n\n🏷 Node: $NODE_NAME\n🆔 ID: $(short_node_id)\n🟢 Durum: $status\n🚀 Başlangıç: $(format_epoch "$node_started")\n⏱ Çalışma süresi: $(human_duration "$node_uptime")\n🔐 İmza kalan süre: $(human_duration "$remaining")\n\n🖥 SUNUCU\n$(system_summary)"
    LAST_DAILY_REPORT="$today"
  fi
  save_state
}

show_status() {
  load_config
  local result remaining started current
  result="$(node_state)"
  current="$(now_epoch)"; remaining=$((SIGNED_AT_EPOCH + SIGNATURE_LIFETIME_SECONDS - current))
  started="$(service_started_epoch || true)"; started="${started:-$SIGNED_AT_EPOCH}"
  printf 'Node: %s\nNode başlangıcı: %s\nNode çalışma süresi: %s\nİmza geri sayımı: %s\n%s\n' \
    "${result%%|*} (${result#*|})" "$(format_epoch "$started")" "$(human_duration "$((current - started))")" "$(human_duration "$remaining")" "$(system_summary)"
}

mark_signed() {
  load_config
  SIGNED_AT_EPOCH="$(now_epoch)"; LAST_SIGNATURE_NOTICE=""
  save_state
  telegram "✅ $NODE_NAME: imza yenilemesi kaydedildi. Yeni 14 günlük geri sayım başladı ($(iso_now))."
  echo "İmza yenilemesi kaydedildi."
}

send_report() {
  load_config
  LAST_DAILY_REPORT=""
  save_state
  check
}

install_schedule() {
  local script_path
  script_path="$(cd "$(dirname "$0")" && pwd)/$(basename "$0")"
  if [[ "$(uname)" == "Darwin" ]]; then
    local plist="$HOME/Library/LaunchAgents/network.optimai.telegram-monitor.plist"
    mkdir -p "$(dirname "$plist")"
    cat > "$plist" <<EOF
<?xml version="1.0" encoding="UTF-8"?><!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd"><plist version="1.0"><dict><key>Label</key><string>network.optimai.telegram-monitor</string><key>ProgramArguments</key><array><string>$script_path</string><string>--check</string></array><key>StartInterval</key><integer>900</integer><key>RunAtLoad</key><true/></dict></plist>
EOF
    launchctl bootout "gui/$(id -u)" "$plist" >/dev/null 2>&1 || true
    launchctl bootstrap "gui/$(id -u)" "$plist"
    echo "macOS LaunchAgent kuruldu (15 dakikada bir)."
  else
    local cron_line="*/15 * * * * $script_path --check >/dev/null 2>&1"
    (crontab -l 2>/dev/null | grep -Fv "$script_path --check" || true; echo "$cron_line") | crontab -
    echo "Linux cron görevi kuruldu (15 dakikada bir)."
  fi
}

install() {
  ensure_home
  local token
  read -r -s -p 'Telegram bot token: ' token; echo
  [[ -n "$token" ]] || { echo "Token zorunlu." >&2; exit 1; }
  BOT_TOKEN="$token"
  verify_bot_token || { echo "Geçersiz Telegram bot token'ı. BotFather'ın verdiği HTTP API token'ını (123456:AA... biçiminde) girin; bot kullanıcı adı veya sayısal bot ID'si kullanılmaz." >&2; exit 1; }
  detect_chat_id || { echo "Chat ID otomatik alınamadı. Botunuza /start gönderip tekrar deneyin." >&2; exit 1; }
  if ! detect_node_identity; then
    echo "Node adı otomatik okunamadı. OptimAI CLI açık ve node device komutu çalışır durumda olmalı." >&2
    exit 1
  fi
  echo "Bulunan node: $DETECTED_NODE_NAME ($DETECTED_NODE_ID)"
  umask 077
  {
    printf 'BOT_TOKEN=%q\n' "$token"
    printf 'CHAT_ID=%q\n' "$CHAT_ID"
    printf 'NODE_NAME=%q\n' "$DETECTED_NODE_NAME"
    printf 'NODE_ID=%q\n' "$DETECTED_NODE_ID"
  } > "$CONFIG_FILE"
  SIGNED_AT_EPOCH="$(initial_signature_time)"; LAST_NODE_STATE="unknown"; LAST_SIGNATURE_NOTICE=""; LAST_DAILY_REPORT=""
  save_state
  chmod 600 "$CONFIG_FILE" "$STATE_FILE"
  install_schedule
  check
  echo "Kurulum tamamlandı. İmzayı bugün yenilemediyseniz, yenilediğiniz anda: $0 --mark-signed"
}

uninstall() {
  local script_path plist
  script_path="$(cd "$(dirname "$0")" && pwd)/$(basename "$0")"
  if [[ "$(uname)" == "Darwin" ]]; then
    plist="$HOME/Library/LaunchAgents/network.optimai.telegram-monitor.plist"
    launchctl bootout "gui/$(id -u)" "$plist" >/dev/null 2>&1 || true
    rm -f "$plist"
  else
    (crontab -l 2>/dev/null | grep -Fv "$script_path --check" || true) | crontab -
  fi
  rm -f "$CONFIG_FILE" "$STATE_FILE"
  rmdir "$APP_HOME" 2>/dev/null || true
  echo "Monitor zamanlayıcısı ve yerel Telegram yapılandırması kaldırıldı."
}

case "${1:---help}" in
  --install) install ;;
  --check) check ;;
  --status) show_status ;;
  --report) send_report ;;
  --mark-signed) mark_signed ;;
  --uninstall) uninstall ;;
  --help|-h) echo "Kullanım: $0 --install | --check | --status | --report | --mark-signed | --uninstall" ;;
  *) echo "Bilinmeyen seçenek: $1" >&2; exit 2 ;;
esac
