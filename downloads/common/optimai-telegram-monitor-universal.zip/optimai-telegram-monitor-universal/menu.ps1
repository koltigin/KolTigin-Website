Write-Host '1) Türkçe'; Write-Host '2) English'
$language = Read-Host 'Dil / Language [1-2]'
if ($language -notin @('1','2')) { throw 'Geçersiz seçim / Invalid selection' }
Write-Host 'Operating system selection / İşletim sistemi seçimi'
Write-Host '1) Ubuntu/Linux'; Write-Host '2) macOS'; Write-Host '3) Windows'
$selected = Read-Host '>'
if ($selected -ne '3') { throw 'Bu paket Windows üzerinde çalışıyor. Windows seçeneğini kullanın. / This package is running on Windows. Select Windows.' }
& (Join-Path $PSScriptRoot 'install-windows-cli-node.ps1') -Action Install
