param([ValidateSet('Install','Uninstall')][string]$Action = 'Install')
$AppDir = Join-Path $env:LOCALAPPDATA 'OptimAI-Telegram-Monitor'
$Monitor = Join-Path $AppDir 'OptimAI-Telegram-Monitor.ps1'
if ($Action -eq 'Uninstall') {
  if (Test-Path $Monitor) { & $Monitor -Action Uninstall }
  Remove-Item -LiteralPath $AppDir -Recurse -Force -ErrorAction SilentlyContinue
  Write-Host 'OptimAI Telegram Monitor removed.'
  exit
}
if (!(Get-Command optimai-cli -ErrorAction SilentlyContinue)) { throw 'optimai-cli was not found.' }
if (!(Get-Command docker -ErrorAction SilentlyContinue)) { throw 'Docker was not found.' }
New-Item -ItemType Directory -Path $AppDir -Force | Out-Null
Copy-Item (Join-Path $PSScriptRoot 'OptimAI-Telegram-Monitor.ps1') $Monitor -Force
Copy-Item $PSCommandPath (Join-Path $AppDir 'install-windows-cli-node.ps1') -Force
& $Monitor -Action Install
