#!/usr/bin/env bash
set -euo pipefail
APP_DIR="$HOME/.local/lib/optimai-telegram-monitor"
SOURCE_DIR="$(cd "$(dirname "$0")" && pwd)"
MONITOR="$APP_DIR/optimai-telegram-monitor.sh"
[[ "$(uname)" == Darwin ]] || { echo 'Bu kurulum yalnızca macOS içindir.' >&2; exit 1; }
if [[ "${1:-}" == --uninstall ]]; then
  [[ -x "$MONITOR" ]] && "$MONITOR" --uninstall || true
  rm -rf "$APP_DIR"
  echo 'OptimAI Telegram Monitor kaldırıldı.'
  exit 0
fi
command -v optimai-cli >/dev/null || { echo 'optimai-cli bulunamadı.' >&2; exit 1; }
command -v docker >/dev/null || { echo 'Docker bulunamadı.' >&2; exit 1; }
optimai-cli node device >/dev/null || { echo 'Node device bilgisi okunamadı.' >&2; exit 1; }
mkdir -p "$APP_DIR"
install -m 755 "$SOURCE_DIR/optimai-telegram-monitor.sh" "$MONITOR"
install -m 755 "$0" "$APP_DIR/install-macos-cli-node.sh"
"$MONITOR" --install
