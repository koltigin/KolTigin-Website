#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "$0")" && pwd)"
echo "1) Türkçe"; echo "2) English"
read -r -p 'Dil / Language [1-2]: ' LANGUAGE
case "$LANGUAGE" in 1) MSG='İşletim sistemi seçimi' ;; 2) MSG='Operating system selection' ;; *) echo 'Geçersiz seçim / Invalid selection'; exit 2 ;; esac
echo "$MSG"; echo '1) Ubuntu/Linux'; echo '2) macOS'; echo '3) Windows'
read -r -p '> ' SELECTED
case "$(uname -s)" in
  Linux) [[ "$SELECTED" == 1 ]] || { echo 'Bu paket Linux üzerinde çalışıyor / This package is running on Linux.'; exit 2; }; exec "$ROOT_DIR/install-optimai-cli-telegram-monitor.sh" ;;
  Darwin) [[ "$SELECTED" == 2 ]] || { echo 'Bu paket macOS üzerinde çalışıyor / This package is running on macOS.'; exit 2; }; exec "$ROOT_DIR/install-macos-cli-node.sh" ;;
  *) echo 'Windows için menu.ps1 dosyasını PowerShell ile çalıştırın / Run menu.ps1 in PowerShell for Windows.'; exit 2 ;;
esac
