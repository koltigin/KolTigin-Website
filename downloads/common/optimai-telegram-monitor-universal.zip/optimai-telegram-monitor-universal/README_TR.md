# OptimAI Telegram Monitor

Linux (Ubuntu), macOS ve Windows üzerinde çalışan OptimAI CLI node'ları için yerel sağlık ve imza-hatırlatma aracıdır. Her kullanıcı kendi Telegram bot token'ını ve chat ID'sini girer; veriler başka bir sunucuya gönderilmez, yalnızca Telegram Bot API'ye gider.

## Neleri izler?

- Node süreci / Ubuntu'da `optimai.service` ve Docker kullanılabilirliği
- Günlük özet: node durumu, disk, bellek ve makine bilgisi
- İmza yenileme için 14 günlük geri sayım
- Tekrarsız uyarılar: 7 gün, 3 gün, 24 saat, 6 saat ve süre dolumu

OptimAI'nin CLI oturum durumu, çalışan node'un imza geçerliliğiyle güvenilir biçimde aynı olmadığından bu araç `auth status` sonucunu imza kaynağı kabul etmez. İmza yenilendiğinde kullanıcı sayaç kaydını kendisi günceller.

Araç imza atmaz, cüzdan/seed phrase istemez, node'u başlatmaz veya yeniden başlatmaz.

## Telegram bilgileri

1. BotFather ile bir bot oluşturup token'ını alın.
2. Botunuza `/start` gönderin.
3. `https://api.telegram.org/bot<TOKEN>/getUpdates` adresinden `chat.id` değerini bulun. Token'ı kimseyle paylaşmayın.

## Ubuntu / macOS

Ubuntu Clean Node için release paketini açıp tek komutla kurulum yapın:

```bash
sudo ./install-optimai-cli-telegram-monitor.sh
```

Bu betik aktif `optimai.service`, Docker, node adı/ID ve systemd başlangıç zamanını doğrular; ardından yalnızca Telegram token ve chat ID ister.

macOS için doğrudan monitor betiğini kullanın:

```bash
chmod +x optimai-telegram-monitor.sh
./optimai-telegram-monitor.sh --install
```

Kurulum yalnızca token ve chat ID sorar. Ubuntu Clean Node'da `systemctl show optimai.service -p ActiveEnterTimestamp --value` ile servis başlangıcını otomatik bulur ve bunu 14 günlük imza sayacının başlangıcı olarak kaydeder; kullanıcıdan tarih istenmez. Her kontrolde bu zaman yeniden okunur: node yeniden başlatılmışsa sayaç otomatik olarak yeni başlangıç zamanına eşitlenir. Node adı ve benzersiz node ID, `optimai-cli node device` ile otomatik okunur; kullanıcıdan istenmez. Bilgiler `~/.config/optimai-telegram-monitor/` altında yalnızca kullanıcı okuyabilecek şekilde saklanır. Ubuntu'da cron, macOS'ta LaunchAgent her 15 dakikada bir kontrol eder.

İmzayı yeniledikten hemen sonra:

```bash
./optimai-telegram-monitor.sh --mark-signed
```

Anlık durum:

```bash
./optimai-telegram-monitor.sh --status
```

Ubuntu'da farklı bir systemd servis adı kullanılıyorsa kurulumdan önce:

```bash
export OPTIMAI_SERVICE_NAME=my-optimai.service
./optimai-telegram-monitor.sh --install
```

## Windows

Yönetici olmayan PowerShell'de, dosyanın bulunduğu klasörde:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\OptimAI-Telegram-Monitor.ps1 -Action Install
```

Windows Task Scheduler 15 dakikalık görev oluşturur. İmzayı yeniledikten sonra:

```powershell
.\OptimAI-Telegram-Monitor.ps1 -Action MarkSigned
```

## Güvenlik ve sınırlar

- Token, chat ID ve node adı yerelde saklanır. Token sızarsa BotFather üzerinden hemen yenileyin.
- Bot token'ı shell komutuna argüman olarak yazmayın; kurulumdaki gizli istemi kullanın.
- İmza yenilemesi manuel kalır. Bu, kullanıcı cüzdanı kontrolünü korur.
- Bu ilk sürümde Windows/macOS node tespiti `optimai-cli` işlemi ve Docker'a dayanır. Kullanıcıların farklı servis/işlem adları için sonraki sürümde ayar eklenebilir.

## Kaldırma

Ubuntu Clean Node'da monitorü, 15 dakikalık cron görevini ve yerelde tutulan token/chat ID yapılandırmasını kaldırmak için:

```bash
sudo /usr/local/lib/optimai-telegram-monitor/install-optimai-cli-telegram-monitor.sh --uninstall
```

Bu işlem Telegram bot hesabını silmez. Botu tamamen kapatmak için BotFather'da `/deletebot` kullanın veya token sızdıysa `/revoke` ile token'ı yenileyin.
